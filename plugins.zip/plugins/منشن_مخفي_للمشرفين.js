const { downloadMediaMessage } = require('@whiskeysockets/baileys');

module.exports = {
  command: 'مخفيم',
  category: 'tools',
  description: '📢 منشن جماعي للأدمنز فقط (مخصص لأدمنز القروب).',

  async execute(sock, msg, args = []) {
    try {
      const groupJid = msg.key.remoteJid;
      const senderJid = msg.key.participant || msg.participant || groupJid;

      if (!groupJid.endsWith('@g.us')) {
        return sock.sendMessage(groupJid, {
          text: '🚫 هذا الأمر يعمل فقط داخل *المجموعات*.'
        }, { quoted: msg });
      }

      const metadata = await sock.groupMetadata(groupJid);
      
      // جلب الأدمنز فقط
      const admins = metadata.participants
        .filter(p => p.admin)
        .map(p => p.id);

      // التحقق أن المرسل أدمن
      if (!admins.includes(senderJid)) {
        return sock.sendMessage(groupJid, {
          text: '🔒 هذا الأمر مخصص لأدمنز القروب فقط.'
        }, { quoted: msg });
      }

      if (admins.length === 0) {
        return sock.sendMessage(groupJid, {
          text: '⚠️ لا يوجد أدمنز في هذا الجروب.'
        }, { quoted: msg });
      }

      const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const quotedMsgKey = msg.message?.extendedTextMessage?.contextInfo?.stanzaId;
      const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;

      if (quoted) {
        const messageType = Object.keys(quoted)[0];

        if (['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'].includes(messageType)) {
          const stream = await downloadMediaMessage(
            {
              key: { remoteJid: groupJid, id: quotedMsgKey, fromMe: false, participant: quotedParticipant },
              message: quoted
            },
            'buffer',
            {},
            { logger: console }
          );

          const sendObj = {
            mimetype: quoted[messageType].mimetype,
            contextInfo: { mentionedJid: admins },
          };

          if (messageType === 'imageMessage') sendObj.image = stream;
          else if (messageType === 'videoMessage') sendObj.video = stream;
          else if (messageType === 'audioMessage') sendObj.audio = stream;
          else if (messageType === 'documentMessage') sendObj.document = stream;
          else if (messageType === 'stickerMessage') sendObj.sticker = stream;

          return await sock.sendMessage(groupJid, sendObj, { quoted: msg });

        } else if (quoted.conversation || quoted.extendedTextMessage?.text) {
          const text = quoted.conversation || quoted.extendedTextMessage.text;
          return sock.sendMessage(groupJid, {
            text: `${text}`,
            mentions: admins
          }, { quoted: msg });

        } else {
          return sock.sendMessage(groupJid, {
            text: '⚠️ لا يمكن إعادة إرسال هذا النوع من الرسائل.',
          }, { quoted: msg });
        }

      } else {
        return sock.sendMessage(groupJid, {
          text: `📢 منشن لأدمنز القروب`,
          mentions: admins
        }, { quoted: msg });
      }

    } catch (err) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: `❌ *حدث خطأ داخل الكود:*\n\`\`\`${err.message || err.toString()}\`\`\``
      }, { quoted: msg });
    }
  }
};